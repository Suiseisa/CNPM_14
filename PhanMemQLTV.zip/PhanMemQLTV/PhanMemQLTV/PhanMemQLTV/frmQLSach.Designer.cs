﻿namespace PhanMemQLTV
{
    partial class frmQLSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQLSach));
            this.grpTTSach = new System.Windows.Forms.GroupBox();
            this.cboMaNXB = new System.Windows.Forms.ComboBox();
            this.lblNhapTinhTrang = new System.Windows.Forms.Label();
            this.lblNhapSLNhap = new System.Windows.Forms.Label();
            this.lblNhapCD = new System.Windows.Forms.Label();
            this.lblNhapSLCon = new System.Windows.Forms.Label();
            this.lblNhapDonGia = new System.Windows.Forms.Label();
            this.lblNhapTenNXB = new System.Windows.Forms.Label();
            this.lblNhapTenTG = new System.Windows.Forms.Label();
            this.lblNhapTenSach = new System.Windows.Forms.Label();
            this.cboTinhTrang = new System.Windows.Forms.ComboBox();
            this.lblTinhTrang = new System.Windows.Forms.Label();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.txtSLNhap = new System.Windows.Forms.TextBox();
            this.lblSLNhap = new System.Windows.Forms.Label();
            this.lblChuDe = new System.Windows.Forms.Label();
            this.lblNamXB = new System.Windows.Forms.Label();
            this.lblMaNXB = new System.Windows.Forms.Label();
            this.lblTacGia = new System.Windows.Forms.Label();
            this.txtChuDe = new System.Windows.Forms.TextBox();
            this.txtNamXB = new System.Windows.Forms.TextBox();
            this.txtTacGia = new System.Windows.Forms.TextBox();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.lblTenSach = new System.Windows.Forms.Label();
            this.txtMaSach = new System.Windows.Forms.TextBox();
            this.lblMaSach = new System.Windows.Forms.Label();
            this.dataGridViewDSSach = new System.Windows.Forms.DataGridView();
            this.colMaSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenSach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenLoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenTG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaNXB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNamXB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colGhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.grpTimKiem = new System.Windows.Forms.GroupBox();
            this.txtNDTimKiem = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radTenCD = new System.Windows.Forms.RadioButton();
            this.radTenTG = new System.Windows.Forms.RadioButton();
            this.radTenSach = new System.Windows.Forms.RadioButton();
            this.radMaSach = new System.Windows.Forms.RadioButton();
            this.errTenSach = new System.Windows.Forms.ErrorProvider(this.components);
            this.errTG = new System.Windows.Forms.ErrorProvider(this.components);
            this.errMaNXB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errNamXB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errCD = new System.Windows.Forms.ErrorProvider(this.components);
            this.errSLNhap = new System.Windows.Forms.ErrorProvider(this.components);
            this.errDonGia = new System.Windows.Forms.ErrorProvider(this.components);
            this.errTinhTrang = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblTTTenNXB = new System.Windows.Forms.Label();
            this.txtTTTenNXB = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnXoaDSSach = new System.Windows.Forms.Button();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnLoadDS = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.grpTTSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSSach)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grpTimKiem.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errTenSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMaNXB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errNamXB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSLNhap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errDonGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTinhTrang)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpTTSach
            // 
            this.grpTTSach.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.grpTTSach.Controls.Add(this.cboMaNXB);
            this.grpTTSach.Controls.Add(this.lblNhapTinhTrang);
            this.grpTTSach.Controls.Add(this.lblNhapSLNhap);
            this.grpTTSach.Controls.Add(this.lblNhapCD);
            this.grpTTSach.Controls.Add(this.lblNhapSLCon);
            this.grpTTSach.Controls.Add(this.lblNhapDonGia);
            this.grpTTSach.Controls.Add(this.lblNhapTenNXB);
            this.grpTTSach.Controls.Add(this.lblNhapTenTG);
            this.grpTTSach.Controls.Add(this.lblNhapTenSach);
            this.grpTTSach.Controls.Add(this.cboTinhTrang);
            this.grpTTSach.Controls.Add(this.lblTinhTrang);
            this.grpTTSach.Controls.Add(this.txtGhiChu);
            this.grpTTSach.Controls.Add(this.lblGhiChu);
            this.grpTTSach.Controls.Add(this.txtDonGia);
            this.grpTTSach.Controls.Add(this.lblDonGia);
            this.grpTTSach.Controls.Add(this.txtSLNhap);
            this.grpTTSach.Controls.Add(this.lblSLNhap);
            this.grpTTSach.Controls.Add(this.lblChuDe);
            this.grpTTSach.Controls.Add(this.lblNamXB);
            this.grpTTSach.Controls.Add(this.lblMaNXB);
            this.grpTTSach.Controls.Add(this.lblTacGia);
            this.grpTTSach.Controls.Add(this.txtChuDe);
            this.grpTTSach.Controls.Add(this.txtNamXB);
            this.grpTTSach.Controls.Add(this.txtTacGia);
            this.grpTTSach.Controls.Add(this.txtTenSach);
            this.grpTTSach.Controls.Add(this.lblTenSach);
            this.grpTTSach.Controls.Add(this.txtMaSach);
            this.grpTTSach.Controls.Add(this.lblMaSach);
            this.grpTTSach.Location = new System.Drawing.Point(165, 159);
            this.grpTTSach.Name = "grpTTSach";
            this.grpTTSach.Size = new System.Drawing.Size(956, 175);
            this.grpTTSach.TabIndex = 2;
            this.grpTTSach.TabStop = false;
            this.grpTTSach.Text = "Thông tin sách";
            // 
            // cboMaNXB
            // 
            this.cboMaNXB.FormattingEnabled = true;
            this.cboMaNXB.Location = new System.Drawing.Point(216, 109);
            this.cboMaNXB.Name = "cboMaNXB";
            this.cboMaNXB.Size = new System.Drawing.Size(217, 30);
            this.cboMaNXB.TabIndex = 3;
            this.cboMaNXB.SelectedIndexChanged += new System.EventHandler(this.cboMaNXB_SelectedIndexChanged);
            // 
            // lblNhapTinhTrang
            // 
            this.lblNhapTinhTrang.AutoSize = true;
            this.lblNhapTinhTrang.Location = new System.Drawing.Point(590, 107);
            this.lblNhapTinhTrang.Name = "lblNhapTinhTrang";
            this.lblNhapTinhTrang.Size = new System.Drawing.Size(0, 22);
            this.lblNhapTinhTrang.TabIndex = 10;
            // 
            // lblNhapSLNhap
            // 
            this.lblNhapSLNhap.AutoSize = true;
            this.lblNhapSLNhap.Location = new System.Drawing.Point(650, 49);
            this.lblNhapSLNhap.Name = "lblNhapSLNhap";
            this.lblNhapSLNhap.Size = new System.Drawing.Size(0, 22);
            this.lblNhapSLNhap.TabIndex = 10;
            // 
            // lblNhapCD
            // 
            this.lblNhapCD.AutoSize = true;
            this.lblNhapCD.Location = new System.Drawing.Point(590, 17);
            this.lblNhapCD.Name = "lblNhapCD";
            this.lblNhapCD.Size = new System.Drawing.Size(0, 22);
            this.lblNhapCD.TabIndex = 10;
            // 
            // lblNhapSLCon
            // 
            this.lblNhapSLCon.AutoSize = true;
            this.lblNhapSLCon.Location = new System.Drawing.Point(590, 47);
            this.lblNhapSLCon.Name = "lblNhapSLCon";
            this.lblNhapSLCon.Size = new System.Drawing.Size(0, 22);
            this.lblNhapSLCon.TabIndex = 10;
            // 
            // lblNhapDonGia
            // 
            this.lblNhapDonGia.AutoSize = true;
            this.lblNhapDonGia.Location = new System.Drawing.Point(590, 78);
            this.lblNhapDonGia.Name = "lblNhapDonGia";
            this.lblNhapDonGia.Size = new System.Drawing.Size(0, 22);
            this.lblNhapDonGia.TabIndex = 10;
            // 
            // lblNhapTenNXB
            // 
            this.lblNhapTenNXB.AutoSize = true;
            this.lblNhapTenNXB.Location = new System.Drawing.Point(200, 119);
            this.lblNhapTenNXB.Name = "lblNhapTenNXB";
            this.lblNhapTenNXB.Size = new System.Drawing.Size(0, 22);
            this.lblNhapTenNXB.TabIndex = 10;
            // 
            // lblNhapTenTG
            // 
            this.lblNhapTenTG.AutoSize = true;
            this.lblNhapTenTG.Location = new System.Drawing.Point(200, 88);
            this.lblNhapTenTG.Name = "lblNhapTenTG";
            this.lblNhapTenTG.Size = new System.Drawing.Size(0, 22);
            this.lblNhapTenTG.TabIndex = 10;
            // 
            // lblNhapTenSach
            // 
            this.lblNhapTenSach.AutoSize = true;
            this.lblNhapTenSach.Location = new System.Drawing.Point(200, 58);
            this.lblNhapTenSach.Name = "lblNhapTenSach";
            this.lblNhapTenSach.Size = new System.Drawing.Size(0, 22);
            this.lblNhapTenSach.TabIndex = 9;
            // 
            // cboTinhTrang
            // 
            this.cboTinhTrang.FormattingEnabled = true;
            this.cboTinhTrang.Items.AddRange(new object[] {
            "Mới",
            "Cũ"});
            this.cboTinhTrang.Location = new System.Drawing.Point(611, 108);
            this.cboTinhTrang.Name = "cboTinhTrang";
            this.cboTinhTrang.Size = new System.Drawing.Size(230, 30);
            this.cboTinhTrang.TabIndex = 8;
            // 
            // lblTinhTrang
            // 
            this.lblTinhTrang.AutoSize = true;
            this.lblTinhTrang.Location = new System.Drawing.Point(517, 110);
            this.lblTinhTrang.Name = "lblTinhTrang";
            this.lblTinhTrang.Size = new System.Drawing.Size(101, 22);
            this.lblTinhTrang.TabIndex = 0;
            this.lblTinhTrang.Text = "Tình trạng :";
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(611, 139);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(230, 30);
            this.txtGhiChu.TabIndex = 9;
            // 
            // lblGhiChu
            // 
            this.lblGhiChu.AutoSize = true;
            this.lblGhiChu.Location = new System.Drawing.Point(517, 144);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(78, 22);
            this.lblGhiChu.TabIndex = 0;
            this.lblGhiChu.Text = "Ghi chú:";
            // 
            // txtDonGia
            // 
            this.txtDonGia.Location = new System.Drawing.Point(611, 77);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(230, 30);
            this.txtDonGia.TabIndex = 7;
            // 
            // lblDonGia
            // 
            this.lblDonGia.AutoSize = true;
            this.lblDonGia.Location = new System.Drawing.Point(517, 80);
            this.lblDonGia.Name = "lblDonGia";
            this.lblDonGia.Size = new System.Drawing.Size(84, 22);
            this.lblDonGia.TabIndex = 0;
            this.lblDonGia.Text = "Đơn giá :";
            // 
            // txtSLNhap
            // 
            this.txtSLNhap.Location = new System.Drawing.Point(611, 47);
            this.txtSLNhap.Name = "txtSLNhap";
            this.txtSLNhap.Size = new System.Drawing.Size(230, 30);
            this.txtSLNhap.TabIndex = 6;
            // 
            // lblSLNhap
            // 
            this.lblSLNhap.AutoSize = true;
            this.lblSLNhap.Location = new System.Drawing.Point(517, 50);
            this.lblSLNhap.Name = "lblSLNhap";
            this.lblSLNhap.Size = new System.Drawing.Size(79, 22);
            this.lblSLNhap.TabIndex = 0;
            this.lblSLNhap.Text = "SL nhập:";
            // 
            // lblChuDe
            // 
            this.lblChuDe.AutoSize = true;
            this.lblChuDe.Location = new System.Drawing.Point(517, 18);
            this.lblChuDe.Name = "lblChuDe";
            this.lblChuDe.Size = new System.Drawing.Size(71, 22);
            this.lblChuDe.TabIndex = 0;
            this.lblChuDe.Text = "Chủ đề:";
            // 
            // lblNamXB
            // 
            this.lblNamXB.AutoSize = true;
            this.lblNamXB.Location = new System.Drawing.Point(125, 146);
            this.lblNamXB.Name = "lblNamXB";
            this.lblNamXB.Size = new System.Drawing.Size(90, 22);
            this.lblNamXB.TabIndex = 0;
            this.lblNamXB.Text = "Năm XB :";
            // 
            // lblMaNXB
            // 
            this.lblMaNXB.AutoSize = true;
            this.lblMaNXB.Location = new System.Drawing.Point(125, 116);
            this.lblMaNXB.Name = "lblMaNXB";
            this.lblMaNXB.Size = new System.Drawing.Size(88, 22);
            this.lblMaNXB.TabIndex = 0;
            this.lblMaNXB.Text = "Mã NXB:";
            // 
            // lblTacGia
            // 
            this.lblTacGia.AutoSize = true;
            this.lblTacGia.Location = new System.Drawing.Point(125, 86);
            this.lblTacGia.Name = "lblTacGia";
            this.lblTacGia.Size = new System.Drawing.Size(75, 22);
            this.lblTacGia.TabIndex = 0;
            this.lblTacGia.Text = "Tác giả:";
            // 
            // txtChuDe
            // 
            this.txtChuDe.Location = new System.Drawing.Point(611, 15);
            this.txtChuDe.Name = "txtChuDe";
            this.txtChuDe.Size = new System.Drawing.Size(230, 30);
            this.txtChuDe.TabIndex = 5;
            // 
            // txtNamXB
            // 
            this.txtNamXB.Location = new System.Drawing.Point(216, 140);
            this.txtNamXB.Name = "txtNamXB";
            this.txtNamXB.Size = new System.Drawing.Size(217, 30);
            this.txtNamXB.TabIndex = 4;
            // 
            // txtTacGia
            // 
            this.txtTacGia.Location = new System.Drawing.Point(216, 80);
            this.txtTacGia.Name = "txtTacGia";
            this.txtTacGia.Size = new System.Drawing.Size(217, 30);
            this.txtTacGia.TabIndex = 2;
            // 
            // txtTenSach
            // 
            this.txtTenSach.Location = new System.Drawing.Point(216, 50);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(217, 30);
            this.txtTenSach.TabIndex = 1;
            // 
            // lblTenSach
            // 
            this.lblTenSach.AutoSize = true;
            this.lblTenSach.Location = new System.Drawing.Point(125, 56);
            this.lblTenSach.Name = "lblTenSach";
            this.lblTenSach.Size = new System.Drawing.Size(91, 22);
            this.lblTenSach.TabIndex = 0;
            this.lblTenSach.Text = "Tên sách :";
            // 
            // txtMaSach
            // 
            this.txtMaSach.Location = new System.Drawing.Point(216, 21);
            this.txtMaSach.Name = "txtMaSach";
            this.txtMaSach.Size = new System.Drawing.Size(217, 30);
            this.txtMaSach.TabIndex = 0;
            // 
            // lblMaSach
            // 
            this.lblMaSach.AutoSize = true;
            this.lblMaSach.Location = new System.Drawing.Point(125, 26);
            this.lblMaSach.Name = "lblMaSach";
            this.lblMaSach.Size = new System.Drawing.Size(87, 22);
            this.lblMaSach.TabIndex = 0;
            this.lblMaSach.Text = "Mã sách :";
            this.lblMaSach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dataGridViewDSSach
            // 
            this.dataGridViewDSSach.AllowUserToAddRows = false;
            this.dataGridViewDSSach.AllowUserToDeleteRows = false;
            this.dataGridViewDSSach.AllowUserToResizeRows = false;
            this.dataGridViewDSSach.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridViewDSSach.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewDSSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSSach.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaSach,
            this.colTenSach,
            this.colTenLoai,
            this.colTenTG,
            this.colMaNXB,
            this.colNamXB,
            this.colSoLuong,
            this.colDonGia,
            this.colTinhTrang,
            this.colGhiChu});
            this.dataGridViewDSSach.Location = new System.Drawing.Point(45, 20);
            this.dataGridViewDSSach.Name = "dataGridViewDSSach";
            this.dataGridViewDSSach.ReadOnly = true;
            this.dataGridViewDSSach.RowHeadersWidth = 62;
            this.dataGridViewDSSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDSSach.Size = new System.Drawing.Size(1081, 380);
            this.dataGridViewDSSach.TabIndex = 2;
            this.dataGridViewDSSach.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDSSach_RowEnter);
            // 
            // colMaSach
            // 
            this.colMaSach.DataPropertyName = "MaSach";
            this.colMaSach.HeaderText = "Mã sách";
            this.colMaSach.MinimumWidth = 8;
            this.colMaSach.Name = "colMaSach";
            this.colMaSach.ReadOnly = true;
            this.colMaSach.Width = 60;
            // 
            // colTenSach
            // 
            this.colTenSach.DataPropertyName = "TenSach";
            this.colTenSach.HeaderText = "Tên sách";
            this.colTenSach.MinimumWidth = 8;
            this.colTenSach.Name = "colTenSach";
            this.colTenSach.ReadOnly = true;
            this.colTenSach.Width = 170;
            // 
            // colTenLoai
            // 
            this.colTenLoai.DataPropertyName = "ChuDe";
            this.colTenLoai.HeaderText = "Chủ đề";
            this.colTenLoai.MinimumWidth = 8;
            this.colTenLoai.Name = "colTenLoai";
            this.colTenLoai.ReadOnly = true;
            this.colTenLoai.Width = 80;
            // 
            // colTenTG
            // 
            this.colTenTG.DataPropertyName = "TacGia";
            this.colTenTG.HeaderText = "Tác giả";
            this.colTenTG.MinimumWidth = 8;
            this.colTenTG.Name = "colTenTG";
            this.colTenTG.ReadOnly = true;
            this.colTenTG.Width = 150;
            // 
            // colMaNXB
            // 
            this.colMaNXB.DataPropertyName = "MaNXB";
            this.colMaNXB.HeaderText = "Mã NXB";
            this.colMaNXB.MinimumWidth = 8;
            this.colMaNXB.Name = "colMaNXB";
            this.colMaNXB.ReadOnly = true;
            this.colMaNXB.Width = 120;
            // 
            // colNamXB
            // 
            this.colNamXB.DataPropertyName = "NamXB";
            this.colNamXB.HeaderText = "Năm XB";
            this.colNamXB.MinimumWidth = 8;
            this.colNamXB.Name = "colNamXB";
            this.colNamXB.ReadOnly = true;
            this.colNamXB.Width = 120;
            // 
            // colSoLuong
            // 
            this.colSoLuong.DataPropertyName = "SLNhap";
            this.colSoLuong.HeaderText = "SL nhập";
            this.colSoLuong.MinimumWidth = 8;
            this.colSoLuong.Name = "colSoLuong";
            this.colSoLuong.ReadOnly = true;
            this.colSoLuong.Width = 50;
            // 
            // colDonGia
            // 
            this.colDonGia.DataPropertyName = "DonGia";
            this.colDonGia.HeaderText = "Đơn giá";
            this.colDonGia.MinimumWidth = 8;
            this.colDonGia.Name = "colDonGia";
            this.colDonGia.ReadOnly = true;
            this.colDonGia.Width = 60;
            // 
            // colTinhTrang
            // 
            this.colTinhTrang.DataPropertyName = "TinhTrang";
            this.colTinhTrang.HeaderText = "Tình trạng";
            this.colTinhTrang.MinimumWidth = 8;
            this.colTinhTrang.Name = "colTinhTrang";
            this.colTinhTrang.ReadOnly = true;
            this.colTinhTrang.Width = 70;
            // 
            // colGhiChu
            // 
            this.colGhiChu.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colGhiChu.DataPropertyName = "GhiChu";
            this.colGhiChu.HeaderText = "Ghi chú";
            this.colGhiChu.MinimumWidth = 8;
            this.colGhiChu.Name = "colGhiChu";
            this.colGhiChu.ReadOnly = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.dataGridViewDSSach);
            this.groupBox2.Location = new System.Drawing.Point(56, 376);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1167, 422);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Danh sách sách:";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox3.Controls.Add(this.grpTimKiem);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Location = new System.Drawing.Point(165, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(969, 85);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm kiếm sách";
            // 
            // grpTimKiem
            // 
            this.grpTimKiem.Controls.Add(this.txtNDTimKiem);
            this.grpTimKiem.Location = new System.Drawing.Point(554, 12);
            this.grpTimKiem.Name = "grpTimKiem";
            this.grpTimKiem.Size = new System.Drawing.Size(380, 60);
            this.grpTimKiem.TabIndex = 1;
            this.grpTimKiem.TabStop = false;
            this.grpTimKiem.Text = "Nhập thông tin cần tìm kiếm:";
            // 
            // txtNDTimKiem
            // 
            this.txtNDTimKiem.Location = new System.Drawing.Point(11, 24);
            this.txtNDTimKiem.Name = "txtNDTimKiem";
            this.txtNDTimKiem.Size = new System.Drawing.Size(363, 30);
            this.txtNDTimKiem.TabIndex = 0;
            this.txtNDTimKiem.TextChanged += new System.EventHandler(this.txtNDTimKiem_TextChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radTenCD);
            this.groupBox4.Controls.Add(this.radTenTG);
            this.groupBox4.Controls.Add(this.radTenSach);
            this.groupBox4.Controls.Add(this.radMaSach);
            this.groupBox4.Location = new System.Drawing.Point(31, 18);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(474, 54);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tìm theo:";
            // 
            // radTenCD
            // 
            this.radTenCD.AutoSize = true;
            this.radTenCD.Location = new System.Drawing.Point(336, 24);
            this.radTenCD.Name = "radTenCD";
            this.radTenCD.Size = new System.Drawing.Size(121, 26);
            this.radTenCD.TabIndex = 3;
            this.radTenCD.TabStop = true;
            this.radTenCD.Text = "Tên chủ đề";
            this.radTenCD.UseVisualStyleBackColor = true;
            // 
            // radTenTG
            // 
            this.radTenTG.AutoSize = true;
            this.radTenTG.Location = new System.Drawing.Point(217, 24);
            this.radTenTG.Name = "radTenTG";
            this.radTenTG.Size = new System.Drawing.Size(122, 26);
            this.radTenTG.TabIndex = 2;
            this.radTenTG.TabStop = true;
            this.radTenTG.Text = "Tên tác giả";
            this.radTenTG.UseVisualStyleBackColor = true;
            // 
            // radTenSach
            // 
            this.radTenSach.AutoSize = true;
            this.radTenSach.Location = new System.Drawing.Point(116, 24);
            this.radTenSach.Name = "radTenSach";
            this.radTenSach.Size = new System.Drawing.Size(105, 26);
            this.radTenSach.TabIndex = 1;
            this.radTenSach.TabStop = true;
            this.radTenSach.Text = "Tên sách";
            this.radTenSach.UseVisualStyleBackColor = true;
            // 
            // radMaSach
            // 
            this.radMaSach.AutoSize = true;
            this.radMaSach.Location = new System.Drawing.Point(18, 24);
            this.radMaSach.Name = "radMaSach";
            this.radMaSach.Size = new System.Drawing.Size(101, 26);
            this.radMaSach.TabIndex = 0;
            this.radMaSach.TabStop = true;
            this.radMaSach.Text = "Mã sách";
            this.radMaSach.UseVisualStyleBackColor = true;
            // 
            // errTenSach
            // 
            this.errTenSach.ContainerControl = this;
            // 
            // errTG
            // 
            this.errTG.ContainerControl = this;
            // 
            // errMaNXB
            // 
            this.errMaNXB.ContainerControl = this;
            // 
            // errNamXB
            // 
            this.errNamXB.ContainerControl = this;
            // 
            // errCD
            // 
            this.errCD.ContainerControl = this;
            // 
            // errSLNhap
            // 
            this.errSLNhap.ContainerControl = this;
            // 
            // errDonGia
            // 
            this.errDonGia.ContainerControl = this;
            // 
            // errTinhTrang
            // 
            this.errTinhTrang.ContainerControl = this;
            // 
            // lblTTTenNXB
            // 
            this.lblTTTenNXB.AutoSize = true;
            this.lblTTTenNXB.Location = new System.Drawing.Point(123, 25);
            this.lblTTTenNXB.Name = "lblTTTenNXB";
            this.lblTTTenNXB.Size = new System.Drawing.Size(92, 22);
            this.lblTTTenNXB.TabIndex = 11;
            this.lblTTTenNXB.Text = "Tên NXB:";
            // 
            // txtTTTenNXB
            // 
            this.txtTTTenNXB.Location = new System.Drawing.Point(216, 19);
            this.txtTTTenNXB.Name = "txtTTTenNXB";
            this.txtTTTenNXB.Size = new System.Drawing.Size(217, 30);
            this.txtTTTenNXB.TabIndex = 12;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox1.Controls.Add(this.txtTTTenNXB);
            this.groupBox1.Controls.Add(this.lblTTTenNXB);
            this.groupBox1.Location = new System.Drawing.Point(165, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(482, 55);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin tên NXB";
            // 
            // btnXoaDSSach
            // 
            this.btnXoaDSSach.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnXoaDSSach.Location = new System.Drawing.Point(819, 335);
            this.btnXoaDSSach.Name = "btnXoaDSSach";
            this.btnXoaDSSach.Size = new System.Drawing.Size(137, 39);
            this.btnXoaDSSach.TabIndex = 14;
            this.btnXoaDSSach.Text = "Xoá danh sách";
            this.btnXoaDSSach.UseVisualStyleBackColor = true;
            this.btnXoaDSSach.Click += new System.EventHandler(this.btnXoaDSSach_Click);
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Image = global::PhanMemQLTV.Properties.Resources.Dakirby309_Simply_Styled_Microsoft_Excel_2013;
            this.btnExportExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportExcel.Location = new System.Drawing.Point(657, 335);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(137, 39);
            this.btnExportExcel.TabIndex = 10;
            this.btnExportExcel.Text = "Xuất Excel";
            this.btnExportExcel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // btnLoadDS
            // 
            this.btnLoadDS.Image = global::PhanMemQLTV.Properties.Resources._1482846500_recycle;
            this.btnLoadDS.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadDS.Location = new System.Drawing.Point(875, 115);
            this.btnLoadDS.Name = "btnLoadDS";
            this.btnLoadDS.Size = new System.Drawing.Size(160, 39);
            this.btnLoadDS.TabIndex = 1;
            this.btnLoadDS.Text = "Load danh sách";
            this.btnLoadDS.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoadDS.UseVisualStyleBackColor = true;
            this.btnLoadDS.Click += new System.EventHandler(this.btnLoadDS_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Image = global::PhanMemQLTV.Properties.Resources.home_icon1;
            this.btnThoat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThoat.Location = new System.Drawing.Point(709, 115);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(160, 39);
            this.btnThoat.TabIndex = 8;
            this.btnThoat.Text = "Trang chủ";
            this.btnThoat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Image = global::PhanMemQLTV.Properties.Resources.onebit_35;
            this.btnHuy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHuy.Location = new System.Drawing.Point(982, 334);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(101, 39);
            this.btnHuy.TabIndex = 7;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.Image = global::PhanMemQLTV.Properties.Resources.Paomedia_Small_N_Flat_Floppy;
            this.btnLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLuu.Location = new System.Drawing.Point(545, 335);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(88, 39);
            this.btnLuu.TabIndex = 6;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Image = global::PhanMemQLTV.Properties.Resources.Graphicloads_100_Flat_Close;
            this.btnXoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoa.Location = new System.Drawing.Point(428, 335);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(85, 39);
            this.btnXoa.TabIndex = 5;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnSua
            // 
            this.btnSua.Image = global::PhanMemQLTV.Properties.Resources.Custom_Icon_Design_Pretty_Office_7_Save_as;
            this.btnSua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSua.Location = new System.Drawing.Point(298, 335);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(99, 39);
            this.btnSua.TabIndex = 4;
            this.btnSua.Text = "Sửa";
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnThem
            // 
            this.btnThem.Image = global::PhanMemQLTV.Properties.Resources.add32;
            this.btnThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnThem.Location = new System.Drawing.Point(174, 335);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(93, 39);
            this.btnThem.TabIndex = 3;
            this.btnThem.Text = "Thêm";
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // frmQLSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(1270, 810);
            this.Controls.Add(this.btnXoaDSSach);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnExportExcel);
            this.Controls.Add(this.btnLoadDS);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.grpTTSach);
            this.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmQLSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý sách";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmQLSach_Load);
            this.grpTTSach.ResumeLayout(false);
            this.grpTTSach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSSach)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.grpTimKiem.ResumeLayout(false);
            this.grpTimKiem.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errTenSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errMaNXB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errNamXB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSLNhap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errDonGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTinhTrang)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpTTSach;
        private System.Windows.Forms.ComboBox cboTinhTrang;
        private System.Windows.Forms.Label lblTinhTrang;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Label lblDonGia;
        private System.Windows.Forms.TextBox txtSLNhap;
        private System.Windows.Forms.Label lblSLNhap;
        private System.Windows.Forms.Label lblChuDe;
        private System.Windows.Forms.Label lblMaNXB;
        private System.Windows.Forms.Label lblTacGia;
        private System.Windows.Forms.TextBox txtTenSach;
        private System.Windows.Forms.Label lblTenSach;
        private System.Windows.Forms.TextBox txtMaSach;
        private System.Windows.Forms.Label lblMaSach;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.DataGridView dataGridViewDSSach;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radTenSach;
        private System.Windows.Forms.RadioButton radMaSach;
        private System.Windows.Forms.GroupBox grpTimKiem;
        private System.Windows.Forms.TextBox txtNDTimKiem;
        private System.Windows.Forms.Button btnLoadDS;
        private System.Windows.Forms.RadioButton radTenCD;
        private System.Windows.Forms.RadioButton radTenTG;
        private System.Windows.Forms.Label lblNhapTenSach;
        private System.Windows.Forms.Label lblNhapTinhTrang;
        private System.Windows.Forms.Label lblNhapSLNhap;
        private System.Windows.Forms.Label lblNhapCD;
        private System.Windows.Forms.Label lblNhapSLCon;
        private System.Windows.Forms.Label lblNhapDonGia;
        private System.Windows.Forms.Label lblNhapTenNXB;
        private System.Windows.Forms.Label lblNhapTenTG;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Label lblGhiChu;
        private System.Windows.Forms.Label lblNamXB;
        private System.Windows.Forms.TextBox txtChuDe;
        private System.Windows.Forms.TextBox txtNamXB;
        private System.Windows.Forms.TextBox txtTacGia;
        private System.Windows.Forms.ErrorProvider errTenSach;
        private System.Windows.Forms.ErrorProvider errTG;
        private System.Windows.Forms.ErrorProvider errMaNXB;
        private System.Windows.Forms.ErrorProvider errNamXB;
        private System.Windows.Forms.ErrorProvider errCD;
        private System.Windows.Forms.ErrorProvider errSLNhap;
        private System.Windows.Forms.ErrorProvider errDonGia;
        private System.Windows.Forms.ErrorProvider errTinhTrang;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.ComboBox cboMaNXB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenSach;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenLoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenTG;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaNXB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNamXB;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTinhTrang;
        private System.Windows.Forms.DataGridViewTextBoxColumn colGhiChu;
        private System.Windows.Forms.TextBox txtTTTenNXB;
        private System.Windows.Forms.Label lblTTTenNXB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnXoaDSSach;
    }
}