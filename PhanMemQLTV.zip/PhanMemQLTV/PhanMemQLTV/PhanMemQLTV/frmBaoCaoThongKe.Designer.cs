﻿namespace PhanMemQLTV
{
    partial class frmBaoCaoThongKe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBaoCaoThongKe));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtSLSachQuaHan = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTongGiaTriSach = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSLCon = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtSLMuon = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSLCuon = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSLDauSach = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnXemSLSachQuaHan = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSLDGQuaHan = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSLDGMuon = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSLDocGia = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSLDGQuaHan = new System.Windows.Forms.Button();
            this.dataGridViewDSDGQuaHan = new System.Windows.Forms.DataGridView();
            this.btnHome = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtSLNhanVien = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtSLNhaXuatBan = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSDGQuaHan)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtSLSachQuaHan);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtTongGiaTriSach);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtSLCon);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtSLMuon);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtSLCuon);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtSLDauSach);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(273, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(747, 123);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thống kê sách:";
            // 
            // txtSLSachQuaHan
            // 
            this.txtSLSachQuaHan.Location = new System.Drawing.Point(508, 59);
            this.txtSLSachQuaHan.Name = "txtSLSachQuaHan";
            this.txtSLSachQuaHan.Size = new System.Drawing.Size(208, 30);
            this.txtSLSachQuaHan.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(400, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 22);
            this.label10.TabIndex = 0;
            this.label10.Text = "SL quá hạn:";
            // 
            // txtTongGiaTriSach
            // 
            this.txtTongGiaTriSach.Location = new System.Drawing.Point(508, 89);
            this.txtTongGiaTriSach.Name = "txtTongGiaTriSach";
            this.txtTongGiaTriSach.Size = new System.Drawing.Size(208, 30);
            this.txtTongGiaTriSach.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(400, 92);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 22);
            this.label12.TabIndex = 0;
            this.label12.Text = "Tổng giá trị:";
            // 
            // txtSLCon
            // 
            this.txtSLCon.Location = new System.Drawing.Point(508, 29);
            this.txtSLCon.Name = "txtSLCon";
            this.txtSLCon.Size = new System.Drawing.Size(208, 30);
            this.txtSLCon.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(400, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 22);
            this.label11.TabIndex = 0;
            this.label11.Text = "SL còn:";
            // 
            // txtSLMuon
            // 
            this.txtSLMuon.Location = new System.Drawing.Point(129, 84);
            this.txtSLMuon.Name = "txtSLMuon";
            this.txtSLMuon.Size = new System.Drawing.Size(191, 30);
            this.txtSLMuon.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "SL mượn:";
            // 
            // txtSLCuon
            // 
            this.txtSLCuon.Location = new System.Drawing.Point(129, 54);
            this.txtSLCuon.Name = "txtSLCuon";
            this.txtSLCuon.Size = new System.Drawing.Size(191, 30);
            this.txtSLCuon.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "SL cuốn:";
            // 
            // txtSLDauSach
            // 
            this.txtSLDauSach.Location = new System.Drawing.Point(129, 24);
            this.txtSLDauSach.Name = "txtSLDauSach";
            this.txtSLDauSach.Size = new System.Drawing.Size(191, 30);
            this.txtSLDauSach.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "SL đầu sách:";
            // 
            // btnXemSLSachQuaHan
            // 
            this.btnXemSLSachQuaHan.Location = new System.Drawing.Point(485, 329);
            this.btnXemSLSachQuaHan.Name = "btnXemSLSachQuaHan";
            this.btnXemSLSachQuaHan.Size = new System.Drawing.Size(150, 39);
            this.btnXemSLSachQuaHan.TabIndex = 2;
            this.btnXemSLSachQuaHan.Text = "DS sách quá hạn";
            this.btnXemSLSachQuaHan.UseVisualStyleBackColor = true;
            this.btnXemSLSachQuaHan.Click += new System.EventHandler(this.btnXemSLSachQuaHan_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSLDGQuaHan);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtSLDGMuon);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtSLDocGia);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(273, 165);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(352, 142);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thống kê độc giả:";
            // 
            // txtSLDGQuaHan
            // 
            this.txtSLDGQuaHan.Location = new System.Drawing.Point(161, 97);
            this.txtSLDGQuaHan.Name = "txtSLDGQuaHan";
            this.txtSLDGQuaHan.Size = new System.Drawing.Size(159, 30);
            this.txtSLDGQuaHan.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 22);
            this.label4.TabIndex = 0;
            this.label4.Text = "SL ĐG quá hạn:";
            // 
            // txtSLDGMuon
            // 
            this.txtSLDGMuon.Location = new System.Drawing.Point(161, 59);
            this.txtSLDGMuon.Name = "txtSLDGMuon";
            this.txtSLDGMuon.Size = new System.Drawing.Size(159, 30);
            this.txtSLDGMuon.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(144, 22);
            this.label7.TabIndex = 0;
            this.label7.Text = "SL ĐG đã mượn:";
            // 
            // txtSLDocGia
            // 
            this.txtSLDocGia.Location = new System.Drawing.Point(161, 19);
            this.txtSLDocGia.Name = "txtSLDocGia";
            this.txtSLDocGia.Size = new System.Drawing.Size(159, 30);
            this.txtSLDocGia.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 22);
            this.label8.TabIndex = 0;
            this.label8.Text = "SL độc giả:";
            // 
            // btnSLDGQuaHan
            // 
            this.btnSLDGQuaHan.AutoSize = true;
            this.btnSLDGQuaHan.Location = new System.Drawing.Point(649, 329);
            this.btnSLDGQuaHan.Name = "btnSLDGQuaHan";
            this.btnSLDGQuaHan.Size = new System.Drawing.Size(152, 39);
            this.btnSLDGQuaHan.TabIndex = 2;
            this.btnSLDGQuaHan.Text = "DS ĐG quá hạn";
            this.btnSLDGQuaHan.UseVisualStyleBackColor = true;
            this.btnSLDGQuaHan.Click += new System.EventHandler(this.btnSLDGQuaHan_Click);
            // 
            // dataGridViewDSDGQuaHan
            // 
            this.dataGridViewDSDGQuaHan.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewDSDGQuaHan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDSDGQuaHan.Location = new System.Drawing.Point(6, 17);
            this.dataGridViewDSDGQuaHan.Name = "dataGridViewDSDGQuaHan";
            this.dataGridViewDSDGQuaHan.RowHeadersWidth = 62;
            this.dataGridViewDSDGQuaHan.Size = new System.Drawing.Size(735, 201);
            this.dataGridViewDSDGQuaHan.TabIndex = 2;
            // 
            // btnHome
            // 
            this.btnHome.Image = global::PhanMemQLTV.Properties.Resources.home_icon1;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(347, 328);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(123, 40);
            this.btnHome.TabIndex = 3;
            this.btnHome.Text = "Trang chủ";
            this.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dataGridViewDSDGQuaHan);
            this.groupBox3.Location = new System.Drawing.Point(273, 374);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(747, 224);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Image = global::PhanMemQLTV.Properties.Resources.Dakirby309_Simply_Styled_Microsoft_Excel_2013;
            this.btnExportExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportExcel.Location = new System.Drawing.Point(817, 328);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(118, 40);
            this.btnExportExcel.TabIndex = 5;
            this.btnExportExcel.Text = "Xuất Excel";
            this.btnExportExcel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtSLNhanVien);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(667, 165);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(353, 68);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thống kế nhân viên:";
            // 
            // txtSLNhanVien
            // 
            this.txtSLNhanVien.Location = new System.Drawing.Point(141, 22);
            this.txtSLNhanVien.Name = "txtSLNhanVien";
            this.txtSLNhanVien.Size = new System.Drawing.Size(181, 30);
            this.txtSLNhanVien.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 22);
            this.label5.TabIndex = 2;
            this.label5.Text = "SL nhân viên:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtSLNhaXuatBan);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Location = new System.Drawing.Point(667, 239);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(353, 68);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Thống kê nhà xuất bản:";
            // 
            // txtSLNhaXuatBan
            // 
            this.txtSLNhaXuatBan.Location = new System.Drawing.Point(141, 23);
            this.txtSLNhaXuatBan.Name = "txtSLNhaXuatBan";
            this.txtSLNhaXuatBan.Size = new System.Drawing.Size(181, 30);
            this.txtSLNhaXuatBan.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 22);
            this.label6.TabIndex = 3;
            this.label6.Text = "SL nhà xuất bản:";
            // 
            // frmBaoCaoThongKe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(1215, 643);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btnExportExcel);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnSLDGQuaHan);
            this.Controls.Add(this.btnXemSLSachQuaHan);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmBaoCaoThongKe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Báo cáo - thống kê";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmBaoCaoThongKe_Load);
            this.Click += new System.EventHandler(this.frmBaoCaoThongKe_Click);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDSDGQuaHan)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSLMuon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSLCuon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSLDauSach;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSLDGMuon;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSLDocGia;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSLDGQuaHan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTongGiaTriSach;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSLCon;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridViewDSDGQuaHan;
        private System.Windows.Forms.Button btnXemSLSachQuaHan;
        private System.Windows.Forms.TextBox txtSLSachQuaHan;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnSLDGQuaHan;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtSLNhanVien;
        private System.Windows.Forms.TextBox txtSLNhaXuatBan;
    }
}